# Experiment 6: MobSF Static + Dynamic Analysis

## Aim
To perform comprehensive static and dynamic security analysis of the Android test application using Mobile Security Framework (MobSF) and an Android Emulator, interpreting findings such as CVSS scores, runtime permissions, third-party trackers, and runtime API behavior.

## Apparatus / Tools Required
- **MobSF (Mobile Security Framework v3.8.5)**
- **Android Studio Emulator (Pixel 4 / Android 11 API 30 x86)**
- **Target Application: InsecureBankv2.apk / DIVA APK**
- **Android Debug Bridge (ADB)**

---

## Theory
Mobile Security Framework (MobSF) is an automated, all-in-one mobile application security assessment suite capable of performing both static and dynamic analysis:
1. **Static Analysis**: Inspects the decompiled `AndroidManifest.xml`, requested permissions, source code implementations, hardcoded credentials, and certificate signatures without running the binary.
2. **Dynamic Analysis**: Deploys the application inside an instrumented Android runtime. Utilizing Frida agents and Logcat hooks, it captures real-time network traffic, crypto operations, sensitive IPC intents, and file storage events.

---

## Procedure
1. Verify emulator connectivity via command line: `adb devices`.
2. Start MobSF service and open the dashboard at `http://localhost:8000`.
3. Upload `InsecureBankv2.apk` and inspect the generated Static Analysis report (Permissions, CVSS Score, Trackers).
4. Navigate to the **Dynamic Analysis** tab, attach to the running `emulator-5554`, and launch runtime instrumentation.
5. Exercise application features (login attempt, funds transfer, view statements) on the emulator while MobSF and Logcat monitor operations.
6. Stop instrumentation and compile the security assessment findings.

---

## Technical Proofs & Evidence

### 1. ADB Connectivity & Emulator Detection
![ADB Devices](proofs/01_adb_devices.png)
*Figure 6.1: Active Android emulator connection verified via ADB (`emulator-5554` running Android 11).*

### 2. MobSF Static Analysis Report
![MobSF Static Analysis](proofs/02_mobsf_static_report.png)
*Figure 6.2: MobSF Static Analysis Dashboard showing App Info, CVSS Security Score (28/100 High Risk), Trackers, and Manifest Permissions.*

### 3. MobSF Dynamic Instrumentation Dashboard
![MobSF Dynamic Analysis](proofs/03_mobsf_dynamic_analysis.png)
*Figure 6.3: MobSF Dynamic Analyzer showing "Instrumentation started" and live Frida runtime API hook stream.*

### 4. Real-Time Logcat Capture
![Logcat Capture](proofs/04_logcat_capture.png)
*Figure 6.4: Logcat capture showing application process startup (`com.android.insecurebankv2`) and sensitive credential exposure.*

### 5. Video Demonstration (App Interaction under Live Monitoring)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Sl. No. | Component / Check | Observed Behavior | Security Implication |
|---|---|---|---|
| 1 | Device Connectivity | Emulator `emulator-5554` online with root access | Allows low-level kernel inspection & dynamic instrumentation |
| 2 | Static CVSS Score | Score: 28 / 100 (High Risk) | Multiple hardcoded secrets and unencrypted storage risks detected |
| 3 | Permissions | `INTERNET`, `USE_CREDENTIALS`, `READ_PROFILE` | App requests dangerous permissions exceeding core operational requirements |
| 4 | Trackers | 0 Trackers Detected | No commercial tracking libraries identified in APK assets |
| 5 | Dynamic Monitoring | Frida agent attached to PID 10167 successfully | Runtime method execution, cipher keys, and intents intercepted live |

---

## Precautions
1. Execute tests strictly in an isolated virtualized sandbox environment (AVD).
2. Ensure third-party app installations do not contain real user credentials or production banking tokens.
3. Validate certificate authority (CA) root isolation after running proxy and dynamic interception tools.

---

## Result
Static and dynamic security analysis of the mobile target application was successfully performed using MobSF and the Android Emulator. Application permissions, CVSS risk scores, tracker presence, and live runtime behavior were completely evaluated and documented.

---

## Viva-Voce Questions & Answers
**Q1: What is the primary difference between static and dynamic analysis in mobile pentesting?**  
*Answer:* Static analysis evaluates an application's source code, manifest, and resources without execution. Dynamic analysis monitors the application during runtime inside an emulator or physical device, inspecting memory, network traffic, and API calls.

**Q2: What does a low MobSF Security Score indicate?**  
*Answer:* MobSF scores applications from 0 to 100, where 100 is pristine security. A low score (e.g., 28/100) indicates significant vulnerabilities such as weak cryptography, cleartext traffic allowance, exported activities, and hardcoded credentials.

**Q3: How does MobSF perform dynamic instrumentation on an Android device?**  
*Answer:* MobSF deploys and connects to a `frida-server` binary running as root in `/data/local/tmp/`. It then injects JavaScript hooks into the target process to intercept Java and native API calls.

**Q4: Why should applications avoid requesting `READ_PROFILE` or `USE_CREDENTIALS` unless essential?**  
*Answer:* Under the Principle of Least Privilege, unnecessary dangerous permissions expand the attack surface. If the application is compromised, unauthorized parties gain access to sensitive user identities and device account tokens.

**Q5: What is the purpose of inspecting the Android Logcat during security assessments?**  
*Answer:* Developers frequently log debug information during development. If left in production builds, Logcat may leak sensitive data like encryption keys, session tokens, and passwords to other apps possessing `READ_LOGS`.
