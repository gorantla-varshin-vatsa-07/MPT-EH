# Experiment 9: InsecureBankv2 Full Vulnerability Assessment

## Aim
To perform an exhaustive security vulnerability assessment of the InsecureBankv2 Android application covering insecure data storage, hardcoded secrets, weak session management, unencrypted network communications, and unprotected exported Android components.

## Apparatus / Tools Required
- **InsecureBankv2 Target Application (`com.android.insecurebankv2`)**
- **JADX-GUI Decompiler v1.5.0**
- **Burp Suite Community Edition v2024.9**
- **Android Debug Bridge (ADB)**
- **Android Studio Emulator (Android 11 API 30 x86)**
- **SQLite3 Command-Line Utility**

---

## Theory
Android vulnerability assessments combine static source code review and dynamic runtime inspection against the OWASP Mobile Top 10 standard. Static code analysis discovers design flaws, unencrypted preferences, and exported activities. Dynamic testing verifies these leads by examining live application sandbox storage (`/data/data/<package>/`), intercepting network packets via an HTTP proxy, and querying local SQLite databases.

---

## Procedure
1. Open `InsecureBankv2.apk` in JADX-GUI; inspect `AndroidManifest.xml` for exported components and permissions.
2. Search decompiled Java sources for sensitive keywords (`password`, `crypto`, `key`, `token`, `http://`).
3. Launch the application on the emulator and intercept the login HTTP transaction using Burp Suite.
4. Access the emulator root shell via ADB and inspect sandbox data stored under `/data/data/com.android.insecurebankv2/shared_prefs/mySharedPreferences.xml`.
5. Access the local SQLite database `/data/data/com.android.insecurebankv2/databases/mydb` and execute schema/table queries using `sqlite3`.
6. Compile all static leads and dynamic proof-of-concept exploits into a comprehensive findings table.

---

## Technical Proofs & Evidence

### 1. JADX Manifest View (Exported Components Highlighted)
![JADX Manifest View](proofs/01_jadx_manifest_exported.png)
*Figure 9.1: JADX-GUI showing `AndroidManifest.xml` with vulnerable exported activities (`.PostLogin`, `.DoTransfer`) accessible without authentication.*

### 2. JADX Text Search Dialog (Hardcoded Secrets & Keywords)
![JADX Search Keywords](proofs/02_jadx_search_keywords.png)
*Figure 9.2: JADX search results for keyword `password`, revealing hardcoded encryption key `v grease secret!` in `CryptoClass.java`.*

### 3. Burp Suite Intercepting Cleartext Login Request
![Burp Login Request](proofs/03_burp_login_request.png)
*Figure 9.3: Burp Suite capturing unencrypted HTTP POST `/login` transmission containing plaintext user credentials.*

### 4. SharedPreferences Cleartext Storage Extraction (`adb shell`)
![Shared Preferences Credentials](proofs/04_shared_prefs_credentials.png)
*Figure 9.4: Root shell cat output of `mySharedPreferences.xml`, exposing base64 encoded username `dinesh` and password hashes.*

### 5. SQLite Database User Records Query (`sqlite3`)
![SQLite3 Query Users](proofs/05_sqlite3_query_users.png)
*Figure 9.5: SQLite query output displaying plaintext user records extracted directly from the application's local `mydb` database.*

### 6. Completed Observation & Vulnerability Findings Table
![Observation Table](proofs/06_observation_table.png)
*Figure 9.6: Comprehensive mobile vulnerability assessment matrix detailing discovered risks, proof evidence, and OWASP MSTG mitigations.*

### 7. Video Demonstration (Security Audit Walkthrough)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Findings Matrix
| Finding ID | Vulnerability Title | Severity | OWASP Mobile | Static / Dynamic Evidence | Concrete Remediation |
|---|---|---|---|---|---|
| SEC-01 | Insecure Data Storage | HIGH | M2: Insecure Storage | `mySharedPreferences.xml` holds cleartext base64 username & pass | Migrate to Android `EncryptedSharedPreferences` & Keystore |
| SEC-02 | Hardcoded Master Secret | CRITICAL | M5: Weak Cryptography | Key `v grease secret!` hardcoded in `CryptoClass.java` | Generate keys dynamically in Hardware Security Module (HSM) |
| SEC-03 | Cleartext HTTP Transmission | HIGH | M3: Insecure Comm | Cleartext POST `/login` intercepted via Burp Suite | Enforce HTTPS/TLS via Android Network Security Config |
| SEC-04 | Unauthenticated Exported Activity | HIGH | M1: Improper Platform | `.PostLogin` exported without permission check | Set `android:exported="false"` for internal activities |
| SEC-05 | Unencrypted SQLite Database | MEDIUM | M2: Insecure Storage | Query `SELECT * FROM names;` dumps cleartext records | Enforce database encryption using SQLCipher |

---

## Result
A full security vulnerability assessment of the InsecureBankv2 Android application was successfully executed. Critical vulnerabilities across local data storage, cryptography, network transport, and inter-process communication were verified and documented with reproducible proofs.

---

## Viva-Voce Questions & Answers
**Q1: What security risk occurs when an activity is marked `android:exported="true"` without permissions?**  
*Answer:* Any third-party application on the device can start that activity directly via an explicit Intent (`am start`), bypassing login screens, authentication barriers, and parental controls.

**Q2: Why is Base64 encoding not considered encryption?**  
*Answer:* Base64 is a reversible, deterministic data encoding scheme designed for transport across ASCII-safe mediums. It requires no secret key and can be instantly decoded by anyone.

**Q3: Where does Android store SharedPreferences files on the local filesystem?**  
*Answer:* In the private internal app sandbox directory: `/data/data/<package_name>/shared_prefs/<filename>.xml`. On rooted devices or debuggable builds, this directory is fully readable.

**Q4: How does SQLCipher protect SQLite databases in Android apps?**  
*Answer:* SQLCipher provides transparent, 256-bit AES encryption for all SQLite database files, pages, and journals, ensuring data cannot be extracted even if the database file is pulled via ADB.

**Q5: What is the purpose of `res/xml/network_security_config.xml` in Android?**  
*Answer:* It allows developers to customize network security settings without modifying app code, such as enforcing HTTPS globally, disabling cleartext traffic (`cleartextTrafficPermitted="false"`), and configuring custom certificate pinning.
