# Experiment 13: ASLR Bypass Demonstration (Observation)

## Aim
To observe Address Space Layout Randomization (ASLR) behavior across multiple fresh process launches on the Android emulator and explain how memory entropy mitigates Return-Oriented Programming (ROP) and memory corruption exploits.

## Apparatus / Tools Required
- **Android Studio Emulator (Android 11 API 30 x86)**
- **Android Debug Bridge (ADB Shell)**
- **Target Process / Libraries: Bionic Libc (`libc.so`)**

---

## Theory
Address Space Layout Randomization (ASLR) is a core OS defense mechanism that randomizes the virtual memory addresses of process execution segments (code, heap, stack, and dynamically loaded shared libraries) upon every process start. The global configuration is governed by `/proc/sys/kernel/randomize_va_space`:
- `0`: ASLR Disabled.
- `1`: Conservative Randomization (Shared libraries, stack, mmap randomized).
- `2`: Full Randomization (Heap, stack, mmap, and VDSO randomized).
Because memory addresses shift unpredictable distances between runs, attackers cannot rely on hardcoded gadget addresses, neutralizing simple ROP exploit chains.

---

## Procedure
1. Confirm emulator connectivity: `adb devices`.
2. Inspect the system ASLR kernel configuration: `adb shell cat /proc/sys/kernel/randomize_va_space` (confirm value `2`).
3. Launch a process and examine its memory layout using its process maps: `adb shell cat /proc/<pid>/maps | grep libc.so` (Run 1).
4. Note the base virtual memory address of the loaded library (`libc.so`).
5. Terminate the process, relaunch it to obtain a fresh PID, and inspect its memory map again (Run 2).
6. Compare the base memory addresses between Run 1 and Run 2 side-by-side to calculate address entropy and verify dynamic randomization.

---

## Technical Proofs & Evidence

### 1. Global ASLR Configuration (`randomize_va_space`)
![Randomize VA Space](proofs/01_randomize_va_space.png)
*Figure 13.1: Command prompt verifying global kernel ASLR state is set to `2` (Full Randomization).*

### 2. Process Memory Map (Run 1: PID 4521)
![Memory Map Run 1](proofs/02_maps_run1.png)
*Figure 13.2: Virtual memory layout for Process Run 1 showing `libc.so` mapped at base address `0xed58f000`.*

### 3. Process Memory Map (Run 2: PID 4892)
![Memory Map Run 2](proofs/03_maps_run2.png)
*Figure 13.3: Virtual memory layout for Process Run 2 showing `libc.so` mapped at randomized base address `0xee11a000`.*

### 4. Side-by-Side Memory Map Comparison & Entropy Analysis
![Side-by-Side Comparison](proofs/04_side_by_side_comparison.png)
*Figure 13.4: Comprehensive comparative analysis highlighting the address delta (+0x00b8b000) and mitigation against hardcoded ROP payloads.*

### 5. Video Demonstration (Memory Randomization Observation)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Execution Run | Process ID (PID) | Libc Base Address Range | Stack Segment Range | Address Shift Delta |
|---|---|---|---|---|
| Run 1 | 4521 | `0xed58f000 - 0xed682000` | `0xbfa30000 - 0xbfa51000` | Baseline |
| Run 2 | 4892 | `0xee11a000 - 0xee20d000` | `0xbf812000 - 0xbf833000` | `+0x00b8b000` (~12 MB shift) |

---

## Result
Memory address layout behavior was observed across distinct process launches on the Android emulator. The kernel ASLR parameter was confirmed as fully active (`2`), and virtual base address shifts across runs demonstrated how ASLR effectively eliminates memory predictability.

---

## Viva-Voce Questions & Answers
**Q1: What is the primary purpose of ASLR in modern operating systems?**  
*Answer:* ASLR randomizes the location of executable code, libraries, stack, and heap in memory, preventing attackers from reliably predicting the target addresses needed to jump to injected shellcode or ROP gadgets.

**Q2: What does a value of `2` in `/proc/sys/kernel/randomize_va_space` signify?**  
*Answer:* A value of `2` signifies Full Randomization, ensuring that stack, mmap regions (shared libraries), heap allocated via `brk()`, and VDSO pages are all randomized.

**Q3: How do attackers attempt to bypass ASLR?**  
*Answer:* Attackers bypass ASLR by finding an Information Leak vulnerability (leaking a function pointer to compute the randomized base offset), exploiting non-PIE binaries, or utilizing memory brute-forcing on 32-bit systems with low entropy.

**Q4: What is Position Independent Executable (PIE)?**  
*Answer:* PIE compiles binary machine code such that all internal memory references are relative rather than absolute. This allows the OS to load the entire executable binary at an arbitrary, randomized address in memory.

**Q5: Why is ASLR significantly more secure on 64-bit architectures than 32-bit?**  
*Answer:* 64-bit architectures provide a vastly larger virtual address space, yielding much higher entropy (e.g., 28 to 32 bits of randomness) compared to 32-bit systems (typically 8 to 16 bits), making brute-force guessing practically impossible.
