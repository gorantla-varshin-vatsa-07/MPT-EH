// Frida Dynamic Instrumentation Hook Script
Java.perform(function () {
    console.log("[*] Injected Frida Script for Dynamic Authentication Analysis");

    // Hooking login authentication verification method
    var LoginActivity = Java.use("com.android.insecurebankv2.LoginActivity");
    if (LoginActivity) {
        LoginActivity.checkPassword.overload("java.lang.String").implementation = function (password) {
            console.log("[*] Intercepted call to checkPassword()");
            console.log("[*] Captured password parameter: " + password);
            console.log("[+] Overriding authentication check: Returning true (BYPASS)");
            return true;
        };
    }

    // Hooking standard Java Cryptography API
    var Cipher = Java.use("javax.crypto.Cipher");
    Cipher.doFinal.overload("[B").implementation = function (inputBytes) {
        console.log("[*] Intercepted Cipher.doFinal() execution");
        var result = this.doFinal(inputBytes);
        console.log("[+] Decrypted / Encrypted byte block inspected safely.");
        return result;
    };
});
