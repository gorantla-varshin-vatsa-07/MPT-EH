# Experiment 8: Frida Dynamic Instrumentation

## Aim
To understand Frida Dynamic Instrumentation by authoring JavaScript hooks to intercept Android runtime function calls, bypass login authentication checks, dump decrypted strings from memory, and monitor cryptographic APIs in an authorized test application.

## Apparatus / Tools Required
- **Frida Dynamic Toolkit (`frida-tools` & `frida-server 16.1.4`)**
- **Android Studio Emulator (Android 11 API 30)**
- **Target Application: InsecureBankv2.apk / DIVA APK**
- **JADX Decompiler v1.5.0**
- **Android Debug Bridge (ADB)**

---

## Theory
Frida injects the Google V8 JavaScript engine directly into a running Android process (e.g., Zygote or app process), providing access to the Java Virtual Machine runtime (`Java.perform`) and native memory spaces. A hook replaces an existing Java method's implementation pointer (`.implementation = function(...)`). This allows penetration testers to inspect arguments, modify internal return states (e.g., forcing a failed boolean login check to return `true`), and extract in-memory plaintext encryption keys.

---

## Procedure
1. Verify `frida-server` is running as root on the Android emulator: `adb shell "ps | grep frida"`.
2. Inspect `com.android.insecurebankv2` decompiled source in JADX to locate the authentication validation logic (`LoginActivity.doesUserExist`) and crypto methods (`CryptoClass.aesDeccrypt`).
3. Author the JavaScript hook script `hook_login.js` to override the authentication return value to `true`.
4. Launch and spawn the target application under Frida control: `frida -U -l hook_login.js -f com.android.insecurebankv2 --no-pause`.
5. Enter invalid dummy credentials (`attacker_dummy` / `invalid_pass_999`) on the emulator; verify that authentication succeeds and the post-login dashboard is revealed.
6. Author and execute secondary hooks for `CryptoClass.aesDeccrypt()` and `javax.crypto.Cipher.doFinal()` to capture in-memory keys and plaintext credentials.
7. Document console logs and application screens demonstrating successful runtime tampering.

---

## Technical Proofs & Evidence

### 1. Frida Execution Terminal (Application Spawning)
![Frida Run Terminal](proofs/01_frida_run_terminal.png)
*Figure 8.1: Frida terminal spawning `com.android.insecurebankv2` and successfully injecting JavaScript instrumentation scripts.*

### 2. Frida Console Interception & Authentication Override Log
![Frida Intercept Console](proofs/02_frida_intercept_console.png)
*Figure 8.2: Console log capturing `LoginActivity.doesUserExist()` call, intercepting invalid input credentials, and forcing return value to `true`.*

### 3. Application Post-Login Screen (Authentication Bypass)
![App Login Bypass Screen](proofs/03_app_login_bypass.png)
*Figure 8.3: Android Emulator screen displaying the InsecureBankv2 PostLogin dashboard accessed with invalid dummy credentials.*

### 4. Decrypted String Memory Hook Output
![Decrypted String Hook](proofs/04_decrypted_string_hook.png)
*Figure 8.4: Frida console output intercepting `CryptoClass.aesDeccrypt()` and extracting the hardcoded master key and plaintext password from RAM.*

### 5. Java Crypto API Hook (`javax.crypto.Cipher.doFinal`)
![Crypto Cipher Hook](proofs/05_crypto_cipher_hook.png)
*Figure 8.5: Console output intercepting low-level `javax.crypto.Cipher.doFinal()` parameters, revealing AES algorithm modes, IV bytes, and decrypted strings.*

### 6. Video Demonstration (Live Frida Hooking Demonstration)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Sl. No. | Hook Target | Intercepted Data | Tampered Result | Impact |
|---|---|---|---|---|
| 1 | `LoginActivity.doesUserExist()` | User: `attacker_dummy` | Forced `return true;` | Total authentication bypass |
| 2 | `CryptoClass.aesDeccrypt()` | Key: `v grease secret!` | Intercepted in RAM | Hardcoded master key stolen |
| 3 | `javax.crypto.Cipher.doFinal()` | Mode: `AES/CBC/PKCS5Padding` | Captured byte stream | Plaintext credentials recovered |

---

## Result
Frida dynamic instrumentation JavaScript hooks were successfully developed and executed. The target application's authentication check was completely bypassed with invalid credentials, and runtime cryptographic operations were intercepted to dump in-memory sensitive data.

---

## Viva-Voce Questions & Answers
**Q1: What is the function of `Java.perform()` in a Frida script?**  
*Answer:* `Java.perform()` wraps code inside an execution context that is attached to the target process's Java VM. It ensures the Dalvik/ART runtime thread is accessible before attempting to hook Java classes.

**Q2: What is the difference between spawning (`-f`) and attaching (`-n`) in Frida?**  
*Answer:* Spawning launches the target application from scratch with early instrumentation hooks attached before `Application.onCreate()` executes. Attaching connects to an already-running process, which may miss startup initialization logic.

**Q3: How does Frida intercept methods with multiple overloads?**  
*Answer:* Frida uses the `.overload()` method syntax, specifying exact parameter types, e.g.:  
`targetClass.targetMethod.overload('java.lang.String', 'java.lang.String').implementation = function(a, b) { ... };`

**Q4: How can Android developers detect and prevent Frida dynamic instrumentation?**  
*Answer:* Applications can implement anti-Frida checks such as scanning `/proc/self/maps` for `frida-agent.so`, detecting active TCP sockets listening on default port 27042, checking for ptrace debugging attachment, and verifying code section checksums in native code.

**Q5: What are the security risks associated with storing sensitive keys in static class variables?**  
*Answer:* Static variables reside in plain process heap memory. Anyone running dynamic instrumentation tools like Frida can hook the class or read memory dumps to extract keys without needing to reverse engineer the compilation artifacts.
