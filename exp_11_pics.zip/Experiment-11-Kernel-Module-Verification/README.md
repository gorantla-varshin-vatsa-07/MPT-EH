# Experiment 11: Kernel Module Compilation + Loading in Android Emulator

## Aim
To verify Linux kernel version and CPU architecture in the Android emulator, understand the kernel module (LKM) build and load workflow, and demonstrate the security restrictions that prevent unauthorized module insertion.

## Apparatus / Tools Required
- **Android Studio Emulator (Android 11 API 30 x86)**
- **Android Debug Bridge (ADB)**
- **Windows Command Prompt / Terminal**

---

## Theory
Loadable Kernel Modules (LKMs) execute directly in kernel space (Ring 0). To load successfully, an LKM must match the kernel's exact version, ABI configuration, symbol table, and cryptographic signature (`CONFIG_MODULE_SIG`). Modern Android systems implement strict security controls: verified boot, restrictive SELinux policies (`sys_module` denied to unprivileged contexts), and kernels compiled without module loading or with strict signature enforcement. Attempting to insert an unsigned or incompatible module should result in an `Operation not permitted` rejection.

---

## Procedure
1. Confirm active emulator connectivity using `adb devices`.
2. Inspect and record the active Linux kernel version: `adb shell uname -a`.
3. Inspect and record the device ABI: `adb shell getprop ro.product.cpu.abi`.
4. Attempt to insert a sample/untrusted kernel module into kernel space: `adb shell insmod /data/local/tmp/rootkit.ko`.
5. Capture and document the system rejection error message (`Operation not permitted` / `avc: denied`).
6. Query loaded kernel modules via `adb shell lsmod` and `adb shell cat /proc/modules` to confirm the untrusted module was rejected and remains absent.

---

## Technical Proofs & Evidence

### 1. Kernel Version Identification (`uname -a`)
![Uname Output](proofs/01_uname_output.png)
*Figure 11.1: Command prompt showing kernel release `5.4.249-android11-2-00004-g212a7aaded26-ab10688362` running on the emulator.*

### 2. Device ABI Architecture (`getprop`)
![Getprop ABI Output](proofs/02_getprop_abi_output.png)
*Figure 11.2: Output of `getprop ro.product.cpu.abi` confirming target system architecture as `x86`.*

### 3. Module Insertion Restricted (`insmod: Operation not permitted`)
![Insmod Not Permitted](proofs/03_insmod_not_permitted.png)
*Figure 11.3: Terminal output demonstrating kernel rejection and SELinux denial preventing module loading.*

### 4. Module Absence Verification (`lsmod` & `/proc/modules`)
![Lsmod Modules Absent](proofs/04_lsmod_cat_modules_absent.png)
*Figure 11.4: Querying `/proc/modules` confirming kernel memory integrity is maintained and unauthorized modules are absent.*

### 5. Video Demonstration (Kernel Integrity Verification)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Sl. No. | Parameter / Command | Output Value | Security Assessment |
|---|---|---|---|
| 1 | Kernel Version | `Linux 5.4.249-android11` | Modern Android Generic Kernel Image (GKI) |
| 2 | Target ABI | `x86` (32-bit emulator architecture) | Architecture compatibility requirement |
| 3 | Load Attempt (`insmod`) | `Operation not permitted` | SELinux policy blocks `sys_module` capability |
| 4 | Active Modules (`lsmod`) | Untrusted module absent | Kernel Ring 0 memory integrity verified |

---

## Result
The Android emulator kernel architecture and version were successfully inspected. The system's kernel module loading defenses were tested, demonstrating that unauthorized module insertion is strictly restricted by kernel policy and SELinux enforcement.

---

## Viva-Voce Questions & Answers
**Q1: What is a Loadable Kernel Module (LKM)?**  
*Answer:* An LKM is an object file containing code that can extend the running kernel of an operating system at runtime without needing to reboot the system or recompile the entire kernel.

**Q2: Why do modern Android production builds disallow `insmod`?**  
*Answer:* If an attacker or malicious root exploit could load arbitrary kernel modules, they would achieve unrestricted Ring 0 execution, bypassing all sandbox protections, encryption controls, and SELinux policies.

**Q3: What role does SELinux play in preventing kernel module loading?**  
*Answer:* SELinux defines mandatory access controls. Even if a process runs as root (UID 0), the policy denies the `sys_module` capability to all domains except trusted init services, preventing unauthorized insertion.

**Q4: What is the Android Generic Kernel Image (GKI)?**  
*Answer:* GKI is Google's standardized kernel architecture introduced in Android 11 to solve kernel fragmentation, isolating core kernel code from vendor hardware drivers via well-defined KMI (Kernel Module Interface) abstractions.

**Q5: What command can be used to inspect active kernel log messages regarding policy denials?**  
*Answer:* `adb shell dmesg` or `adb shell "logcat -b events"` can be used to review kernel audit messages (`avc: denied`).
