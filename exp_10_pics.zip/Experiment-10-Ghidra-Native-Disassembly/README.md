# Experiment 10: ARM Disassembly with Ghidra + ROPgadget Basics

## Aim
To identify the architecture, binary sections, and functions in an Android native shared library (`.so`) using the Ghidra reverse engineering suite, and inventory instruction sequences using ROPgadget for exploit mitigation analysis.

## Apparatus / Tools Required
- **Ghidra Software Reverse Engineering Suite v11.1**
- **ROPgadget Tool v6.9+**
- **Sample Android Native Shared Object: `libsample.so` / `libnative.so`**
- **Windows Command Prompt / Terminal**

---

## Theory
Android applications frequently offload performance-critical tasks, proprietary algorithms, and anti-tamper routines to C/C++ compiled native libraries (`.so` files in ELF format) via the Java Native Interface (JNI). Ghidra allows analysts to deconstruct machine code into assembly listings and readable decompiled C pseudocode. ROPgadget scans executable sections for Return-Oriented Programming (ROP) gadgets (short instruction sequences ending in `ret`), which defensive analysts inventory to evaluate binary hardening (e.g., PIE, Stack Canaries).

---

## Procedure
1. Extract the native shared object `libsample.so` from the test APK's `lib/<arch>/` directory.
2. Launch Ghidra, create a new Non-Shared Project, and import `libsample.so`.
3. Inspect the **Program Information** panel to verify ELF executable format, processor architecture (`x86_64`), and endianness.
4. Run Auto Analysis with default analyzers and inspect the **Symbol Tree → Functions** list.
5. Select a critical function (`check_license`), analyze its disassembly listing side-by-side with the Decompiler C pseudocode, and locate potential flaws (e.g., hardcoded secrets or unconstrained memory operations).
6. Execute ROPgadget from the command line: `ROPgadget --binary libsample.so --only "ret"`.
7. Record gadget count and instruction sequences.

---

## Technical Proofs & Evidence

### 1. Ghidra Program Information Panel
![Ghidra Program Information](proofs/01_ghidra_program_info.png)
*Figure 10.1: Ghidra Program Information window displaying ELF 64-bit format, x86_64 architecture, Little Endianness, and GCC compiler metadata.*

### 2. Ghidra Symbol Tree & Function Hierarchy
![Ghidra Symbol Tree](proofs/02_ghidra_symbol_tree.png)
*Figure 10.2: Ghidra Symbol Tree panel detailing imported symbols, exported JNI functions, and disassembled function inventory.*

### 3. Ghidra Disassembly & Decompiler Side-by-Side View
![Ghidra Disassembly and Decompiler](proofs/03_ghidra_disasm_decompiler.png)
*Figure 10.3: Side-by-side CodeBrowser view showing x86 assembly listing on the left and recovered C pseudocode on the right for `check_license`.*

### 4. ROPgadget Terminal Execution & Gadget Count
![ROPgadget Terminal Output](proofs/04_ropgadget_terminal.png)
*Figure 10.4: Command prompt output of `ROPgadget` identifying 42 unique return-oriented instruction gadgets.*

### 5. Video Demonstration (Native Binary Disassembly Walkthrough)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Sl. No. | Analysis Category | Observed Data / Value | Security Relevance |
|---|---|---|---|
| 1 | Binary Format | ELF 64-bit Shared Object | Native shared library loaded via `System.loadLibrary()` |
| 2 | Target Architecture | x86_64 Little Endian | Emulator ABI architecture for native execution |
| 3 | Exported Function | `Java_com_app_Native_checkAuth` | Entry point invoked from Android Java layer |
| 4 | Code Vulnerability | Hardcoded string `SECRET_LICENSE_KEY_2026` | Credential recoverable via static string extraction |
| 5 | Gadget Inventory | 42 return-ending gadgets discovered | Provides baseline for ROP exploit mitigation auditing |

---

## Result
The Android native shared library was successfully disassembled and decompiled using Ghidra. Binary architecture, internal functions, and decompiled C pseudocode were analyzed, and ROPgadget was utilized to inventory return-oriented execution gadgets.

---

## Viva-Voce Questions & Answers
**Q1: What is the Java Native Interface (JNI)?**  
*Answer:* JNI is a foreign function interface programming framework that allows Java code running inside the Android VM to call and be called by native applications and libraries written in C and C++.

**Q2: What is an ELF file in Android?**  
*Answer:* Executable and Linkable Format (ELF) is the standard binary format for compiled executables, shared libraries (`.so`), and core dumps in Linux and Android operating systems.

**Q3: What is Return-Oriented Programming (ROP)?**  
*Answer:* ROP is an advanced exploit technique where an attacker chains together existing small snippets of executable code ending in `ret` instructions ("gadgets") to execute arbitrary logic without injecting new shellcode.

**Q4: How does the Decompiler in Ghidra assist reverse engineers?**  
*Answer:* The decompiler translates low-level machine instructions and assembly registers into high-level, human-readable C-like control flow constructs (`if-else`, loops, functions), speeding up vulnerability discovery.

**Q5: What compiler security flags help protect native Android `.so` libraries against ROP attacks?**  
*Answer:* Compiling with Position Independent Executables (`-fPIE -pie`), Stack Canaries (`-fstack-protector-strong`), Read-Only Relocations (`-Wl,-z,relro,-z,now`), and Control Flow Integrity (`-fsanitize=cfi`).
