# Experiment 7: Burp Suite Proxy + SSL Pinning Bypass with Frida

## Aim
To configure Burp Suite Community Edition as an intercepting proxy for an Android emulator, intercept HTTPS network traffic from a test application, and demonstrate SSL pinning bypass using Frida and Objection.

## Apparatus / Tools Required
- **Burp Suite Community Edition v2024.9**
- **Objection (Runtime Mobile Exploration v1.11.0)**
- **Frida Dynamic Toolkit (`frida-server` on device)**
- **Android Studio Emulator (Android 11 API 30)**
- **Target Application: InsecureBankv2 / DIVA APK**

---

## Theory
SSL Pinning restricts an application to accepting only a predefined server certificate or public key rather than trusting any certificate issued by a system-installed Certificate Authority (CA). When an intercepting proxy like Burp Suite terminates the TLS connection, the application rejects Burp's custom CA, aborting the connection. Runtime instrumentation tools (Frida / Objection) bypass this defense by hooking low-level TLS verification APIs (e.g., `TrustManagerImpl`, `CertificatePinner`) and forcing them to return success regardless of certificate validity.

---

## Procedure
1. In Burp Suite, open **Proxy → Proxy settings** and configure a listener on `127.0.0.1:8080`.
2. Configure the Android emulator Wi-Fi access point proxy to `10.0.2.2:8080`.
3. Export Burp's CA certificate in DER format (`cacert.der`), push to the emulator, and verify installation under **Settings → Security → Encryption & credentials**.
4. Attempt HTTPS communication in the target application; confirm requests are blocked and SSL handshake errors appear in Burp's Event Log.
5. Connect to the application process using Objection: `objection -g com.android.insecurebankv2 explore`.
6. Execute the command: `android sslpinning disable`.
7. Re-trigger the application network requests; verify that HTTPS traffic is now visible and fully intercepted in Burp's **HTTP history** tab.

---

## Technical Proofs & Evidence

### 1. Burp Suite Proxy Listener Configuration
![Burp Proxy Listener](proofs/01_burp_proxy_listener.png)
*Figure 7.1: Burp Suite Proxy listener actively listening on `127.0.0.1:8080` bound to all interfaces.*

### 2. Burp CA Certificate Installed on Emulator
![Burp CA Certificate](proofs/02_burp_ca_installed.png)
*Figure 7.2: Android Emulator Security Settings confirming user certificate installation.*

### 3. Burp HTTP History (Blocked Before Pinning Bypass)
![Burp HTTP History Blocked](proofs/03_burp_history_blocked.png)
*Figure 7.3: Burp Event Log showing `javax.net.ssl.SSLHandshakeException: Certificate unknown` and empty HTTP history due to active SSL pinning.*

### 4. Objection Terminal — SSL Pinning Disable Execution
![Objection Terminal](proofs/04_objection_sslpinning_disable.png)
*Figure 7.4: Objection terminal hooking `TrustManagerImpl` and okhttp3 `CertificatePinner`, successfully disabling SSL pinning.*

### 5. Burp HTTP History (Requests Visible After Bypass)
![Burp HTTP History Visible](proofs/05_burp_history_visible.png)
*Figure 7.5: Burp Suite capturing decrypted HTTPS POST `/login` and `/dotransfer` requests in plaintext following pinning bypass.*

### 6. Video Demonstration (Live Traffic Interception)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Sl. No. | Phase / Step | Observed Behavior | Technical Result |
|---|---|---|---|
| 1 | Proxy Setup | Listener running on `127.0.0.1:8080` | Ready to receive HTTP/HTTPS emulator traffic |
| 2 | Initial App Traffic | TLS Handshake failed: `SSLHandshakeException` | SSL Pinning actively defending against proxy CAs |
| 3 | Objection Injection | `android sslpinning disable` executed | 4 internal TLS trust methods hooked in memory |
| 4 | Post-Bypass Traffic | Plaintext POST `/login` intercepted in Burp | Complete traffic visibility restored for auditing |

---

## Result
Burp Suite was successfully configured as an intercepting proxy for the Android emulator. Active SSL pinning defenses were analyzed and successfully bypassed using Frida and Objection runtime instrumentation, restoring complete HTTPS traffic visibility.

---

## Viva-Voce Questions & Answers
**Q1: What is SSL Pinning and why is it implemented in mobile applications?**  
*Answer:* SSL Pinning binds an application to a specific cryptographic certificate or public key. It prevents Man-in-the-Middle (MITM) attacks by ensuring the app communicates strictly with legitimate backend servers, even if a user or attacker installs a malicious root certificate on the client device.

**Q2: What is the function of the IP address `10.0.2.2` in the Android Emulator?**  
*Answer:* In the default Android Virtual Device network architecture, `10.0.2.2` is a special alias that maps directly to the host machine's loopback interface (`127.0.0.1`).

**Q3: How does Objection's `android sslpinning disable` command work internally?**  
*Answer:* It injects predefined Frida JavaScript hooks that overwrite methods such as `TrustManagerImpl.verifyChain()`, `CertificatePinner.check()`, and OpenSSL/BoringSSL C functions, forcing them to always return an affirmative validation status.

**Q4: Where are user-installed certificates stored in Android 11+?**  
*Answer:* Android 11 stores user-installed certificates in `/data/misc/user/0/cacerts-added/`. By default, apps targeting API level 24+ do not trust user certificates unless explicitly declared in their `network_security_config.xml`.

**Q5: What is the recommended remediation for applications vulnerable to dynamic SSL pinning bypass?**  
*Answer:* Client-side defenses should be layered with tamper-detection, root detection, and Frida detection libraries, alongside server-side Mutual TLS (mTLS) where the client authenticates using a hardware-backed private key stored in the Android Keystore.
