# Experiment 12: AndroL4b CTF Challenges

## Aim
To investigate vulnerable Android inter-app communication patterns (unprotected exported activities and deep links) using the AndroL4b CTF challenge environment, and exploit the flaw to capture the hidden challenge flag.

## Apparatus / Tools Required
- **AndroL4b CTF Challenge Application (`com.androl4b.ctf`)**
- **JADX-GUI Decompiler v1.5.0**
- **Android Debug Bridge (ADB)**
- **Android Studio Emulator (Android 11 API 30)**

---

## Theory
Android components (Activities, Services, Broadcast Receivers, Content Providers) marked with `android:exported="true"` can be invoked by any other application or external interface without authentication unless guarded by custom permissions. Furthermore, activities configuring an `<intent-filter>` with custom URI schemes (`ctf://secret`) can be triggered directly via deep links. Security analysts simulate malicious third-party apps by invoking these exported components directly using the Activity Manager (`am start`), bypassing frontend security controls.

---

## Procedure
1. Confirm the CTF environment is active on the emulator: `adb devices`.
2. Review the challenge brief: "Intent Filter Vulnerability Challenge - Unauthenticated Activity Access".
3. Open the challenge APK in JADX and inspect `AndroidManifest.xml` to locate exported activities configuring intent filters with custom data schemes.
4. Construct a crafted deep link intent using ADB: `adb shell am start -a android.intent.action.VIEW -d "ctf://secret"`.
5. Observe the emulator display: verify that authentication is bypassed and the secret activity displays the challenge flag.
6. Check Logcat for ActivityManager confirmation of external intent dispatch.

---

## Technical Proofs & Evidence

### 1. CTF Challenge Description Screen
![Challenge Description](proofs/01_challenge_description.png)
*Figure 12.1: CTF Challenge Briefing outlining the objective: bypass authentication via unprotected intent filter deep link.*

### 2. JADX Manifest View (Exported Activity & Intent-Filter)
![JADX Manifest Intent Filter](proofs/02_jadx_manifest_intent_filter.png)
*Figure 12.2: Decompiled manifest revealing `SecretFlagActivity` marked `exported="true"` with scheme `ctf` and host `secret`.*

### 3. ADB Command Line Intent Dispatch
![Terminal am start](proofs/03_terminal_am_start.png)
*Figure 12.3: Terminal executing `adb shell am start -a android.intent.action.VIEW -d "ctf://secret"` to invoke the activity.*

### 4. Application Flag Disclosed on Emulator Screen
![App Flag Disclosed](proofs/04_app_flag_disclosed.png)
*Figure 12.4: Emulator screen capturing the disclosed secret activity and successful flag retrieval.*

### 5. Logcat ActivityManager Intent Dispatch Confirmation
![Logcat Activity Manager](proofs/05_logcat_activity_manager.png)
*Figure 12.5: Android system logcat confirming `ActivityTaskManager` starting the secret activity from shell UID 2000.*

### 6. Video Demonstration (CTF Intent Filter Exploitation)
[Watch Demonstration Video](proofs/demo_recording.mp4)

---

## Observation & Result Table
| Step | Target Component | Invocation Input | Result | Flag Captured |
|---|---|---|---|---|
| 1 | Static Audit | Manifest inspection | Found `android:exported="true"` | Lead established |
| 2 | Intent Filter | Scheme `ctf://secret` | Discovered unauthenticated deep link | Target mapped |
| 3 | ADB Exploit | `am start -a VIEW -d ctf://secret` | Privileged activity launched | `CTF{intent_filter_bypass_flag_2026}` |

---

## Result
The AndroL4b CTF Intent Filter challenge was successfully solved. The unauthenticated exported activity was discovered via static manifest analysis and exploited using a crafted deep link intent via ADB, successfully disclosing the hidden challenge flag.

---

## Viva-Voce Questions & Answers
**Q1: What happens if an activity defines an `<intent-filter>` in Android 12+ without specifying `android:exported`?**  
*Answer:* In Android 12 (API level 31) and higher, the build tools and package manager will fail to install or compile the application. `android:exported` must be explicitly declared as `true` or `false`.

**Q2: What is an explicit intent versus an implicit intent?**  
*Answer:* An explicit intent designates the exact target component class name (`setClassName()`). An implicit intent specifies an action, category, or data URI (`android.intent.action.VIEW`), leaving Android's Intent Resolver to determine matching activities.

**Q3: How should developers protect internal activities that need to be launched from notifications or deep links?**  
*Answer:* Developers should require custom signature-level permissions (`android:protectionLevel="signature"`), validate caller identity using `getCallingPackage()`, and enforce token-based session checks before rendering privileged data.

**Q4: What is Intent Spoofing?**  
*Answer:* Intent spoofing occurs when a malicious app sends forged broadcast or activity intents to a vulnerable exported component, triggering unauthorized state changes or privilege escalation.

**Q5: What command can be used in ADB to list all installed packages on a device?**  
*Answer:* `adb shell pm list packages` or `adb shell pm list packages -3` for third-party installed apps.
